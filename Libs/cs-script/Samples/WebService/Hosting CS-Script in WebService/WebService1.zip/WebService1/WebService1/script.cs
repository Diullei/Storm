using System;
using System.IO;

public class Script
{
	static public void CreateFile()
	{
		using (StreamWriter sw = new StreamWriter(@"C:\test.txt"))
			sw.WriteLine("test");
	}
	static public string SayHello()
	{
		return "Hello World!";
	}
	static public string SayHelloUpper()
	{
		return "HELLO WORLD!";
	}
}
