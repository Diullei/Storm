﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using CSScriptLibrary;
using System.Reflection;
using System.IO;

namespace WebService1
{
    /// <summary>
    /// Summary description for Service1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class Service1 : System.Web.Services.WebService
    {
        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }

        [WebMethod]
        public int Sum(int a, int b)
        {
            string scriptCode = @"using System;
                                  class Math
                                  {
                                     static public int Sum(int a, int b)
                                     {
                                        return a + b;
                                     }
                                  }";

            
            AsmHelper script = new AsmHelper(CSScript.LoadCode(scriptCode, null, false));
            return (int)script.Invoke("Math.Sum", a, b);
        }

        [WebMethod]
        public int SumAlternativeImplementation(int a, int b)
        {
            var Sum = CSScript.LoadMethod(
								@"public static int Sum(int a, int b)
                                  {
                                     return a + b;
                                  }")
                                  .GetStaticMethod();

            return (int)Sum(a, b);
        }

        static Assembly ScriptAssembly
        {
            get
			{
                //Put your path here 
                string scriptFile = put correct (accessible from ASP runtime) path here @"\WebService1\WebService1\script.cs";
				if (scriptAssembly == null)
					scriptAssembly = CSScript.Load(scriptFile, null, true);
				return scriptAssembly;
			}
        }
        static Assembly scriptAssembly;

        [WebMethod]
        public string SayHello()
        {
            return (string)new AsmHelper(Service1.ScriptAssembly).Invoke("Script.SayHello");
        }

        [WebMethod]
        public string SayHelloUpper()
        {
            return (string)new AsmHelper(Service1.ScriptAssembly).Invoke("Script.SayHelloUpper");
        }

        [WebMethod]
        public string CreateFile()
        {
            return (string)new AsmHelper(Service1.ScriptAssembly).Invoke("Script.CreateFile");
        }
    }
}
